## Running LeftistHeap test
-----------------------------
To run the LeftistHeap test, you must run the main function of the LeftistHeap class.
This will create output to show that the class is running properly


## Running Autocomplete
-----------------------------
To run Autocomplete, you must run the main function of the ReadCode class. Follow the in
terminal instructions and enjoy!